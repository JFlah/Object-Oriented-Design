/**
 * Created by Jack on 9/25/2016.
 */
public interface ItemDistribution {
    int howManyItems();
}
