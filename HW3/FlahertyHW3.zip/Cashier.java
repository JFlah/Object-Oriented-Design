public interface Cashier {
    void elapseOneSecond(Customer currentCust);
    String whoAmI();
}
